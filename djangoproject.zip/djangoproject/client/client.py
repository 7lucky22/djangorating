import argparse
import requests
import json
import os

CONFIG_FILE = 'config.json'

def save_my_config(url, token):
    with open(CONFIG_FILE, 'w') as f:
        json.dump({'url': url, 'token': token}, f)

def get_config():
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, 'r') as f:
            return json.load(f)
    return None

def zhuce(url, user, email, password):
    reg_url = url + "/zhuce/user/"
    data = {'username': user, 'email': email, 'password': password}
    r = requests.post(reg_url, json=data)
    if r.status_code == 201:
        print("注册成功")
    else:
        print("错误", r.text)

def login(url, user, password):
    login_url = url + "/get_token/"
    data = {'username': user, 'password': password}
    r = requests.post(login_url, json=data)
    if r.status_code == 200:
        token = r.json()['token']
        save_my_config(url, token)
        print("登录成功")
    else:
        print("错误:", r.text)

def logout():
    if os.path.exists(CONFIG_FILE):
        os.remove(CONFIG_FILE)
        print("已退出登录")
    else:
        print("未登录")

def show_keke():
    cfg = get_config()
    if not cfg:
        print("请登录")
        return
    url = cfg['url']
    token = cfg['token']
    headers = {'Authorization': 'Token ' + token}
    r = requests.get(url + "/keke/", headers=headers)
    if r.status_code == 200:
        keke_list = r.json()
        for k in keke_list:
            teachers = [t['name'] for t in k['laoshi']]
            print(f"ID: {k['id']}, 课程: {k['ke']['code_ke']}, 年份: {k['year']}, 学期: {k['xq']}, 老师: {teachers}")
    else:
        print("错误:", r.text)

def see_teachers():
    cfg = get_config()
    if not cfg:
        print("请登录")
        return
    url = cfg['url']
    token = cfg['token']
    headers = {'Authorization': 'Token ' + token}
    r = requests.get(url + "/jiaoshou/", headers=headers)
    if r.status_code == 200:
        teachers = r.json()
        for t in teachers:
            avg = t['pingfen_avg'] if t['pingfen_avg'] != 0 else "未评分"
            print(f"ID: {t['id']}, 名字: {t['name']}, 平均分: {avg}")
    else:
        print("错误:", r.text)

def get_avg_fen(laoshi_id, ke_code):
    cfg = get_config()
    if not cfg:
        print("请登录")
        return
    url = cfg['url']
    token = cfg['token']
    headers = {'Authorization': 'Token ' + token}
    avg_url = url + "/jiaoshou/" + laoshi_id + "/ke/" + ke_code + "/pingfen/"
    r = requests.get(avg_url, headers=headers)
    if r.status_code == 200:
        data = r.json()
        avg = data['pingfen'] if data['pingfen'] != 0 else "未评分"
        print(f"平均分: {avg}")
    else:
        print("错误:", r.text)

def add_fen(laoshi_id, ke_code, nian, xueqi, fen):
    cfg = get_config()
    if not cfg:
        print("请登录")
        return
    url = cfg['url']
    token = cfg['token']
    headers = {'Authorization': 'Token ' + token}
    data = {
        'laoshi_id': int(laoshi_id),
        'ke_code': ke_code,
        'nian': int(nian),
        'xueqi': xueqi,
        'score': int(fen)
    }
    r = requests.post(url + "/pingfen/add/", headers=headers, json=data)
    if r.status_code == 201:
        print("评分提交成功")
    else:
        print("错误:", r.text)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    subparsers = parser.add_subparsers(dest='command')

    # 注册
    reg_cmd = subparsers.add_parser('zhuce', help='注册账号')
    reg_cmd.add_argument('url', help='服务器地址')
    reg_cmd.add_argument('user', help='用户名')
    reg_cmd.add_argument('email', help='邮箱地址')
    reg_cmd.add_argument('password', help='密码')

    # 登录
    login_cmd = subparsers.add_parser('login', help='登录系统')
    login_cmd.add_argument('url', help='服务器地址')
    login_cmd.add_argument('user', help='用户名')
    login_cmd.add_argument('password', help='密码')

    # 退出登录
    logout_cmd = subparsers.add_parser('logout', help='退出登录')

    list_cmd = subparsers.add_parser('list_keke', help='列出所有课程')

    teacher_cmd = subparsers.add_parser('jiaoshou', help='查看教授信息')

    avg_cmd = subparsers.add_parser('pingfen', help='查教授课程平均分')
    avg_cmd.add_argument('jiaoshou_id', help='教授ID')
    avg_cmd.add_argument('ke_code', help='课程编号')

    rate_cmd = subparsers.add_parser('fen', help='给教授评分')
    rate_cmd.add_argument('jiaoshou_id', help='教授ID')
    rate_cmd.add_argument('ke_code', help='课程编号')
    rate_cmd.add_argument('nian', help='年份')
    rate_cmd.add_argument('xueqi', help='学期')
    rate_cmd.add_argument('fen', help='评分1-5')

    args = parser.parse_args()

    if args.command == 'zhuce':
        zhuce(args.url, args.user, args.email, args.password)
    elif args.command == 'login':
        login(args.url, args.user, args.password)
    elif args.command == 'logout':
        logout()
    elif args.command == 'list_keke':
        show_keke()
    elif args.command == 'jiaoshou':
        see_teachers()
    elif args.command == 'pingfen':
        get_avg_fen(args.laoshi_id, args.ke_code)
    elif args.command == 'fen':
        add_fen(args.laoshi_id, args.ke_code, args.nian, args.xueqi, args.fen)
    else:
        parser.print_help()
