from django.contrib import admin
from .models import Jiaoshou, Kecheng, KechengKai, PingFen
# Register your models here.

# 注册到admin中
admin.site.register(Jiaoshou)
admin.site.register(Kecheng)
admin.site.register(KechengKai)
admin.site.register(PingFen)
