from django.db import models
from django.contrib.auth.models import User


# 教授表
class Jiaoshou(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = "Professor"

# 课程信息表
class Kecheng(models.Model):
    code_ke = models.CharField(max_length=10, unique=True, verbose_name="课程编号")
    name_kc = models.CharField(max_length=100, verbose_name="课程名字")


    def __str__(self):
        return self.code_ke + "-" + self.name_kc
    class Meta:
        verbose_name = "Course Information"


# 课程开设表
class KechengKai(models.Model):
    ke = models.ForeignKey(Kecheng, on_delete=models.CASCADE)
    year = models.IntegerField()
    xq = models.CharField(max_length=10, verbose_name="学期")
    laoshi = models.ManyToManyField(Jiaoshou, verbose_name="教课老师")

    def __str__(self):
        return f"{self.ke.code_ke} {self.year} {self.xq}"

    class Meta:
        verbose_name = "Course Schedule"

# 评分表
class PingFen(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name="学生")
    teacher = models.ForeignKey(Jiaoshou, on_delete=models.CASCADE)
    ke_module = models.ForeignKey(KechengKai, on_delete=models.CASCADE, verbose_name="课程")
    fen = models.IntegerField(choices=((1, "1"), (2, "2"), (3, "3"), (4, "4"), (5, "5")), verbose_name="评分")

    def __str__(self):
        return self.user.username + "-" + self.teacher.name + "-" + str(self.fen)

    class Meta:
        unique_together = ('user', 'teacher', 'ke_module')
        verbose_name = "Rating"
