from rest_framework import serializers
from .models import Jiaoshou, Kecheng, KechengKai, PingFen
from django.db.models import Avg

# 课程序列化器
class KechengSerializer(serializers.ModelSerializer):
    class Meta:
        model = Kecheng
        fields = ['code_ke', 'name_kc']

# 教授序列化器
class LaoshiSerializer(serializers.ModelSerializer):
    pingfen_avg = serializers.SerializerMethodField()
    class Meta:
        model = Jiaoshou
        fields = ['id', 'name', 'pingfen_avg']
    def get_pingfen_avg(self, obj):
        # 查询这个教授的评分
        scores = PingFen.objects.filter(teacher=obj)
        if scores:
            avg_score = scores.aggregate(Avg('fen'))['fen__avg']
            return round(avg_score)
        return 0

# 课程开设序列化器
class KeKaiSerializer(serializers.ModelSerializer):
    ke = KechengSerializer()
    laoshi = LaoshiSerializer(many=True)
    class Meta:
        model = KechengKai
        fields = ['id', 'ke', 'year', 'xq', 'laoshi']

# 评分序列化器，提交评分
class PingFenSerializer(serializers.Serializer):
    laoshi_id = serializers.IntegerField()
    ke_code = serializers.CharField()
    nian = serializers.IntegerField()
    xueqi = serializers.CharField()
    score = serializers.IntegerField(min_value=1, max_value=5)

    def create(self, validated_data):
        user = self.context['request'].user

        # 获取教授
        laoshi = Jiaoshou.objects.filter(id=validated_data['laoshi_id']).first()
        if not laoshi:
            raise serializers.ValidationError("教授不存在")

        # 获取课程
        ke = Kecheng.objects.filter(code_ke=validated_data['ke_code']).first()
        if not ke:
            raise serializers.ValidationError("课程未找到")

        # 获取课程开设信息
        ke_kai = KechengKai.objects.filter(
            ke=ke, year=validated_data['nian'], xq=validated_data['xueqi']
        ).first()
        if not ke_kai:
            raise serializers.ValidationError("该课程没有开设")

        # 检查教授是否教授该课程
        if laoshi not in ke_kai.laoshi.all():
            raise serializers.ValidationError("该教授没有教授这门课程")
        print(validated_data['score'])
        # 更新或创建评分
        pingfen, created = PingFen.objects.update_or_create(
            user=user,
            teacher=laoshi,
            ke_module=ke_kai,
            defaults={'fen': validated_data['score']}
        )

        return pingfen

# 输出序列化器
class PingFenOutputSerializer(serializers.ModelSerializer):
    class Meta:
        model = PingFen
        fields = ['user', 'teacher', 'ke_module', 'fen']
