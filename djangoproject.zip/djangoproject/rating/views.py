from django.shortcuts import render
from rest_framework import viewsets, generics, status
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework.permissions import AllowAny
from rest_framework.authtoken.models import Token
from django.contrib.auth.models import User
from django.shortcuts import get_object_or_404
from .models import Jiaoshou, Kecheng, KechengKai, PingFen
from .serialization import LaoshiSerializer, KeKaiSerializer, PingFenSerializer, PingFenOutputSerializer
from django.db.models import Avg

# 查询课程开设
class KeKaiList(viewsets.ReadOnlyModelViewSet):
    # 获取所以课程开设信息
    queryset = KechengKai.objects.all()
    serializer_class = KeKaiSerializer
    # 验证是否登陆
    permission_classes = [IsAuthenticated]

# 查询教授信息
class LaoshiList(viewsets.ReadOnlyModelViewSet):
    queryset = Jiaoshou.objects.all()
    serializer_class = LaoshiSerializer
    permission_classes = [IsAuthenticated]

# 查询某个老师在某课程的平均分
class LaoshiKePingFen(APIView):
    permission_classes = [IsAuthenticated]
    def get(self, request, laoshi_id, ke_code):

        try:
            laoshi = Jiaoshou.objects.get(id=laoshi_id)
        except:
            return Response({"error": "未查询到这个教授！"}, status=status.HTTP_404_NOT_FOUND)
        try:
            ke = Kecheng.objects.get(code_ke=ke_code)
        except:
            return Response({"error": "课程编号不对！"}, status=status.HTTP_404_NOT_FOUND)

        ke_kais = KechengKai.objects.filter(ke=ke, laoshi=laoshi)
        scores = PingFen.objects.filter(teacher=laoshi, ke_module__in=ke_kais)
        if scores:
            avg = scores.aggregate(Avg('fen'))['fen__avg']
            return Response({'pingfen': round(avg)})
        return Response({'pingfen': 0})

# 提交评分
class AddPingFen(generics.CreateAPIView):
    serializer_class = PingFenSerializer
    permission_classes = [IsAuthenticated]

    def create(self, request, *args, **kwargs):
        # 调用父类的create方法
        serializer = self.get_serializer(data=request.data)
        if serializer.is_valid():
            pingfen_instance = serializer.save()
            return Response(PingFenOutputSerializer(pingfen_instance).data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

# 注册用户的视图
class Zhuce(APIView):
    permission_classes = [AllowAny]
    def post(self, request):
        user = request.data.get('username')  # 用户名
        email = request.data.get('email')  # 邮箱
        password = request.data.get('password')  # 密码
        if not user or not email or not password:
            return Response({'error': '确保信息填写完整'}, status=status.HTTP_400_BAD_REQUEST)
        # 检查用户名有没有重复
        if User.objects.filter(username=user):
            return Response({'error': '用户名已被注册过'}, status=status.HTTP_400_BAD_REQUEST)
        # 创建用户
        new_user = User.objects.create_user(username=user, email=email, password=password)
        # 给个token
        token = Token.objects.create(user=new_user)
        return Response({'token': token.key}, status=status.HTTP_201_CREATED)