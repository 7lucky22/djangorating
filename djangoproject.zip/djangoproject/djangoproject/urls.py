"""
URL configuration for djangoproject project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from rest_framework.authtoken.views import obtain_auth_token
from rating.views import KeKaiList, LaoshiList, LaoshiKePingFen, AddPingFen, Zhuce

# 路由器
my_router = DefaultRouter()
my_router.register(r'keke', KeKaiList)  # 课程开设地址
my_router.register(r'jiaoshou', LaoshiList)  # 教授地址

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include(my_router.urls)),
    path('jiaoshou/<int:laoshi_id>/ke/<str:ke_code>/pingfen/', LaoshiKePingFen.as_view()),  # 教授课程平均分
    path('pingfen/add/', AddPingFen.as_view()),  # 提交评分
    path('zhuce/user/', Zhuce.as_view()),  # 注册
    path('get_token/', obtain_auth_token),  # 登录获取token
]

